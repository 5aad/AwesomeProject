const ASSET_PATH = '../assets/images/';

const images = {
  logo: require(`${ASSET_PATH}logo.png`),
  rightArrow: require(`${ASSET_PATH}right-arrow.png`),
  visa: require(`${ASSET_PATH}visa.png`),
};

export default images;
