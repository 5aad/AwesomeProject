import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import LoginSignupScreen from './Screens/LoginSignupScreen';
import AddCard from './Screens/AddCard';
import MyWallet from './Screens/MyWallet';
import Stock from './Screens/Stock';
import Search from './Screens/Search';
import Account from './Screens/Account';
import SplashScreen from './Screens/SplashScreen';
import TabNav from './TabNav';
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      {/* <TabNav /> */}
      <Stack.Navigator initialRouteName="LoginSignupScreen">
        
        <Stack.Screen
          options={{headerShown: false}}
          name="Login"
          component={LoginSignupScreen}
        />
        <Stack.Screen
          
          name="TabNav"
          component={TabNav}
        />
        <Stack.Screen
          options={{headerShown: false}}
          name="Stock"
          component={Stock}
        />
        <Stack.Screen name="AddCard" component={AddCard} />

        <Stack.Screen options={{headerShown: false}} name="Screen" component={SplashScreen} />
        
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
