import React from 'react';
import {View, Text} from 'react-native';
import {LineChart} from 'react-native-chart-kit';
import {Dimensions} from 'react-native';
import {color} from 'react-native-reanimated';

const screenWidth = Dimensions.get('window').width;
const Graph = () => {
  return (
    <View>
      <Text>Analytics</Text>
      <LineChart
        data={{
          labels: ['January', 'February', 'March', 'April', 'May', 'June'],
          datasets: [
            {
              data: [
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
                Math.random() * 100,
              ],
            },
          ],
        }}
        width={screenWidth} // from react-native
        withDots={false}
        withVerticalLines={false}
        withShadow={false}
        height={320}
        yAxisLabel="$"
        yAxisSuffix="k"
        yAxisInterval={1} // optional, defaults to 1
        chartConfig={{
          backgroundColor: '#ffffff',
          backgroundGradientFrom: '#ffffff',
          backgroundGradientTo: '#ffffff',
          decimalPlaces: 1, // optional, defaults to 2dp
          color: (opacity = 1) => `rgba(${0}, ${0}, ${0}, ${1})`,
          strokeWidth: 2,
        }}
        bezier
        style={{
          marginTop: 8,
          marginBottom: 2,
          borderRadius: 16,
          marginRight: 40,
        }}
      />
    </View>
  );
};

export default Graph;
